const express = require('express');
const app = express();
const bodyParser = require('body-parser');
let posts = [];

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

app.get('/', (req, res) => {
  res.render('index.html', { posts });
});

app.get('/new', (req, res) => {
  res.sendFile(__dirname + '/views/new.html');
});

app.post('/add-post', (req, res) => {
  const { title, content } = req.body;
  posts.push({ title, content });
  res.redirect('/');
});

app.get('/post/:id', (req, res) => {
  const id = req.params.id;
  const post = posts[id];
  if (post) {
    res.render('post.html', { post });
  } else {
    res.send('Post not found');
  }
});

app.listen(3000, () => {
  console.log('Blog platform running on http://localhost:3000');
});
